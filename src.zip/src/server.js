const express = require("express");
const app = express();
const port = 5000;

const imageRoutes = require("./routes/image.routes");
const videoRoutes = require("./routes/video.routes");
const pdfRoutes = require("./routes/pdf.routes");

app.use(express.json());
app.use("/api/image", imageRoutes);
app.use("/api/video", videoRoutes);
app.use("/api/pdf", pdfRoutes);

app.listen(port, () => console.log(`Server running on http://localhost:${port}`));
